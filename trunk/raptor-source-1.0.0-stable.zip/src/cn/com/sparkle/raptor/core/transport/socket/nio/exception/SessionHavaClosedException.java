package cn.com.sparkle.raptor.core.transport.socket.nio.exception;

public class SessionHavaClosedException extends Exception{

	public SessionHavaClosedException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SessionHavaClosedException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public SessionHavaClosedException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public SessionHavaClosedException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
